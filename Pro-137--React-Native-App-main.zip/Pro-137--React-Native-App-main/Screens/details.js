import React from "react"
import { View, Text, Stylesheet, Button, Alert } from "react-native"

export default class Details extends React.Component{
    render(){
        return(
            <View>
                <Text>
                    Details
                </Text>
            </View>
        )
    }
}